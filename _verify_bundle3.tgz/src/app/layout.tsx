import type { Metadata } from "next";
import type { ReactNode } from "react";
import { IBM_Plex_Mono, IBM_Plex_Sans, Science_Gothic } from "next/font/google";
import "./globals.css";
import SessionSync from "@/components/auth/SessionSync";
import Header from "@/components/Header";
import Sidebar from "@/components/sidebar/Sidebar";
import SidebarSecondary from "@/components/sidebar/SidebarSecondary";
import SidebarSecondaryGate from "@/components/sidebar/SidebarSecondaryGate";
import { getSession } from "@/lib/auth/session";

const ibmPlexSans = IBM_Plex_Sans({
  variable: "--font-ibm-plex-sans",
  subsets: ["latin"],
});

const ibmPlexMono = IBM_Plex_Mono({
  variable: "--font-ibm-plex-mono",
  subsets: ["latin"],
  weight: ["400", "700"],
});

const scienceGothic = Science_Gothic({
  variable: "--font-science-gothic",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Light Rider · Entropy Platform",
  description: "Entropy management and distribution platform.",
};

export default async function RootLayout({
  children,
}: Readonly<{ children: ReactNode }>) {
  const { isAuthenticated } = await getSession();

  return (
    <html
      lang="en"
      className={`${ibmPlexSans.variable} ${ibmPlexMono.variable} ${scienceGothic.variable} h-full antialiased`}
    >
      <body className="h-full flex flex-col overflow-hidden">
        <SessionSync initialAuthenticated={isAuthenticated} />
        <Header />
        <div className="flex flex-1 min-h-0">
          <Sidebar />
          <SidebarSecondaryGate>
            <SidebarSecondary />
          </SidebarSecondaryGate>
          <main className="flex-1 overflow-y-auto px-4 py-6 lg:px-8">
            {children}
          </main>
        </div>
      </body>
    </html>
  );
}
