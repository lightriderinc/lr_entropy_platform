import type { DirectorySource } from "@/lib/sources/filters";
import { SourceStatus, SourceTagBadge } from "./SourceStatus";

export default function SourceList({ sources }: { sources: DirectorySource[] }) {
  return (
    <div className="overflow-x-auto default-radius border border-gray-100">
      <table className="w-full text-left text-sm">
        <thead className="bg-gray-100">
          <tr>
            <th className="whitespace-nowrap px-4 py-2 font-medium text-gray-700">Name</th>
            <th className="whitespace-nowrap px-4 py-2 font-medium text-gray-700">Type</th>
            <th className="whitespace-nowrap px-4 py-2 font-medium text-gray-700">Tag</th>
            <th className="whitespace-nowrap px-4 py-2 font-medium text-gray-700">Status</th>
          </tr>
        </thead>
        <tbody>
          {sources.map((s) => {
            const comingSoon = s.availability === "coming_soon";
            return (
              <tr
                key={s.id}
                aria-disabled={comingSoon || undefined}
                className={`border-b border-gray-100 transition-colors last:border-bg-white hover:bg-gray-50 ${comingSoon ? "opacity-70" : ""} `}
              >
                <td className="whitespace-nowrap px-4 py-3 font-medium text-gray-800">
                  {s.name}
                </td>
                <td className="px-4 py-3 text-gray-700">{s.type}</td>
                <td className="whitespace-nowrap px-4 py-3">
                  <SourceTagBadge tag={s.tag} />
                </td>
                <td className="whitespace-nowrap px-4 py-3">
                  <SourceStatus source={s} />
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}
